# Advanced Custom Fields

Welcome to the official repository for Advanced Custom Fields WordPress plugin.

-----------------------

* Readme : https://github.com/elliotcondon/acf/blob/master/readme.txt
* WordPress repository: http://wordpress.org/extend/plugins/advanced-custom-fields/
* Website : http://advancedcustomfields.com/
* Documentation: http://www.advancedcustomfields.com/resources/
* Support: http://support.advancedcustomfields.com/