<table cellspacing="5" cellpadding="5" class="widefat" width="400">
			<thead>
			<tr>
			<th width="400"><?php _e('Snilesh.com News','wp-pagenavi-style'); ?>
			</th>
			</tr>
			</thead>
			<tr>
			<td>
			<?php
			ns_wp_common_get_feeds('http://feeds2.feedburner.com/snilesh');
			?>
			</td>
			</tr>
</table>
<br />
<table cellspacing="5" cellpadding="5" class="widefat" width="400">
			<thead>
			<tr>
			<th width="400"><?php _e('Latest Wordpress Themes','wp-pagenavi-style'); ?>
			</th>
			</tr>
			</thead>
			<tr>
			<td>
			<?php
			ns_wp_common_get_feeds('http://wordpressskins.org/feed/');
			?>
			</td>
			</tr>
</table>
<br />
<table cellspacing="5" cellpadding="5" class="widefat" width="400">
			<thead>
			<tr>
			<th width="400"><?php _e('Need Support ?','wp-pagenavi-style'); ?>
			</th>
			</tr>
			</thead>
			<tr>
			<td>
		<?php _e('If you have any problems with this plugin or good ideas for improvements or new features, please talk about them on our website.','wp-pagenavi-style'); ?>
		<br />
		<a href="http://www.snilesh.com/?p=1278" title="WP PageNavi Style" target="_blank">WP PageNavi Style</a>
			</td>
			</tr>			
</table>
<br />
<table cellspacing="5" cellpadding="5" class="widefat" width="400">
			<thead>
			<tr>
			<th scope="col"><?php _e('Like this plugin ?','wp-pagenavi-style'); ?>
			</th>
			</tr>
			</thead>
			<tr>
			<td><p><?php _e('Why not do any or all of the following : ','wp-pagenavi-style'); ?></p></td>
			</tr>
			<tr>
			<td>
			 <ol>
			 <li>
			 <iframe src="http://www.facebook.com/plugins/like.php?app_id=209880945713233&amp;href=http%3A%2F%2Fwww.snilesh.com%2F%3Fp%3D1278&amp;send=false&amp;layout=button_count&amp;width=90&amp;show_faces=true&amp;action=like&amp;colorscheme=light&amp;font=arial&amp;height=21" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:90px; height:21px;" allowTransparency="true"></iframe><script src="http://platform.twitter.com/widgets.js" type="text/javascript"></script><a href="http://twitter.com/share?url=http://www.snilesh.com/?p=1278&via=snilesh&count=horizontal" class="twitter-share-button">Tweet</a>
			 </li>
			 <li><a href="http://wordpress.org/extend/plugins/wp-pagenavi-style/" title="Wordpress PageNavi Style Plugin" target="_blank"><?php _e('Give it a 5 star rating on WordPress.org.','wp-pagenavi-style'); ?></a></li>
			 </ol>
			</td>
			</tr>
</table>

<br />
<table cellspacing="5" cellpadding="5" class="widefat" width="400">
			<thead>
			<tr>
			<th scope="col"><?php _e('Donate $5, $10 or $20!','wp-pagenavi-style'); ?>
			</th>
			</tr>
			</thead>
			<tr>
			<td>
			<p>
			<?php _e('This plugin has cost us countless hours of work, if you use it, please donate a token of your appreciation!','wp-pagenavi-style'); ?>
			</p>
			<a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=YKY7SHDT8GTQG"><img src="<?php echo WP_PAGENAVI_STYLE_PATH;?>/images/btn_donate.gif" alt="Donate" /></a>
			</td>
			</tr>
			<tr><td height="10"></tr></tr>
</table>



